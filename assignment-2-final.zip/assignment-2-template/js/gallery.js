document.addEventListener('DOMContentLoaded', function() {
    const thumbnails = [
        { small: "images/flowers-pink-small.jpg", large: "images/flowers-pink-large.jpg", title: "Pink Flowers" },
        { small: "images/flowers-purple-small.jpg", large: "images/flowers-purple-large.jpg", title: "Purple Flowers" },
        { small: "images/flowers-red-small.jpg", large: "images/flowers-red-large.jpg", title: "Red Flowers" },
        { small: "images/flowers-white-small.jpg", large: "images/flowers-white-large.jpg", title: "White Flowers" },
        { small: "images/flowers-yellow-small.jpg", large: "images/flowers-yellow-large.jpg", title: "Yellow Flowers" }
    ];

    const thumbnailList = document.getElementById('thumbnail-list');
    const featuredImage = document.querySelector('figure img');
    const figCaption = document.querySelector('figcaption');

    thumbnails.forEach((thumbnail, index) => {
        const listItem = document.createElement('li');
        const img = document.createElement('img');
        img.src = thumbnail.small;
        img.alt = `Thumbnail ${index+1}`;
        img.addEventListener('click', () => {
            featuredImage.src = thumbnail.large;
            figCaption.textContent = thumbnail.title;
        });
        listItem.appendChild(img);
        thumbnailList.appendChild(listItem);
    });
});
